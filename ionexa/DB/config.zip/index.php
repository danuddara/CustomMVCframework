<?php
ob_start(); // i18n wants this to be here
/*
 * @project = "iOnexa";
 * @author = "Four Corners Lanka(Pvt) Ltd";
 * @version = 0.1;
 * @date  = "13/06/2013";
 * 
 * The index page of ionexa framework.
 * /***TESTING PHASE**
 */

 
/***session start at the very beginng of our page***/
session_start();

/* include inital setup */

include_once 'includes/init.php';

/*$suc=send_html_mail('pasindu@fclanka.com','Testing','hello world','ionexa@fclhosting.com');

if($suc==true){echo "send";}
mail("pasindu@fclanka.com", "Subject:tsting two", 'hello second', "From:ionexa@fclhosting.com " );*/

?>
