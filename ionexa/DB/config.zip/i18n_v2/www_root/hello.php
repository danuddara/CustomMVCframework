<?php
ob_start();
$language = 'en';
putenv("LANG=$language"); 
setlocale(LC_ALL, $language);
header("content-type: text/html;charset=UTF-8 \r\n");
mb_internal_encoding('UTF-8');
mb_language('uni');


require_once '../i18n_v2/inc/class.I18Nbase.inc.php';

$englisch_translator = new I18Ntranslator('', new I18Nlocale('en'));
$i18n_user 			 =& $englisch_translator->getI18Nuser();





	$i18n_user->setPrefLocale();

	$i18n_user->setPrefTimeFormat();

	$i18n_user->setPrefMeasureSystem();


$translator		= new I18Ntranslator();
$measure 		= new I18Nmeasure('si');
$format_date 	= new I18NformatDate();
$format_number	= new I18NformatNumber();
$format_string	= new I18NformatString();
$browserlang = new I18Nlocale();

// Set the text domain as 'messages'
/*$domain = 'new';
bindtextdomain($domain, "locale"); 
textdomain($domain);*/

echo gettext("A string to be translated would go here. i know its beautiful").'<br/>';

echo gettext("helloo my world").'<br/>';
echo gettext("no_records_found").'<br/>';
echo $translator->_('no_records_found').'<br/>';

echo $translator->getI18NSetting('mode').'<br/>';

echo $englisch_translator->_($translator->getTranslatorLocale()->getI18Nlocale()).'<br/>';

echo $translator->getTranslatorLocale().'<br/>';


echo $i18n_user->getPrefLanguage().'halo<br/>';


echo $format_date->getTimeFormat().'<br/>';




ob_end_flush();

?>

