<?php

/*
 * @project = "iOnexa";
 * @author = "Four Corners Lanka(Pvt) Ltd";
 * @version = 0.1;
 * @date  = "24/06/2013";
 * @class = "errror class";
 * 
 * use this in the registry to handle and display all the errors to the user throughout
 * the system.
 */
?>
