    


<div id="dialog-overlay"></div>
    <div id="dialog-box">
        <div class="dialog-content">
            <div id="dialog-message"><?php if($messages!=null){ echo $messages;} ?></div>
            <a href="#" class="button"><?php echo _('Close');?></a>
        </div>
    </div>
