/**
 * Core Page control JS File
 * WARNING : DO NOT CHANGE ORDER OF FUNCTIONS !!
 *
 */
$(document).ready(function(){

						   });

