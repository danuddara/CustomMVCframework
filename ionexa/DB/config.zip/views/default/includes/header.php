<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <!--  <base href="<?php echo $baseurl ?>"> this is the base url for the page-->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="Content-Language" content="en" />
<title></title>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta name="Author" content="Fourcorners Software"/>
<meta name="description" content="your description"/>
<meta name="keywords" content="your keywords"/>
<link type="image/x-icon" href="favicon.ico" rel="shortcut icon"/>
