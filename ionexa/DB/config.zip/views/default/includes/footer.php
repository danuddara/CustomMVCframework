          </div><!--id="main-content"-->
   
          <div id="footer">
                  <ul id="footer-menu">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Terms and Conditions</a></li>
                    <li><a href="#">Careers</a></li>
                    <li><a href="#">About Ionexa</a></li>
                    <li><a href="#">How it works?</a></li>
                    <li><a href="#">Sitemap</a></li>
                  </ul>
                  <div class="footer-credit"><span class="copyright">All Rights reserved to Ionexa © 2013</span>Website Design and Developed by<a target="_blank" href="http://www.fclanka.com" class="credit">Four Corners</a></div>
          </div>
   </div><!--id="container"-->
</div><!--id="wrapper"-->

</body>
</html>
