<table class="event-calendar">
    <thead>
        <tr>
            <th colspan="13">
                I am having a (Event from Basic info) on (date from Basic info) at (from basic info) and would like you guys to send me this information ASAP.<br/>
                Hope to see you at the (Event from Basic info)
            </th>
        </tr>    
            <tr>
                <td>Invitee</td>
                <td>suggest Dates</td>
                <td colspan="2">Will attend</td>
                <td colspan="5">Dietary restrictions</td>
                <td>Allergies</td>
                <td colspan="3">Spirits[y/n]</td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                
                <td>No of Adults</td>
                <td>No of Kids</td>
                
                <td>No of Meat</td>
                <td>No of Beef</td>
                <td>No of Pork</td>
                <td>Vegetarian</td>
                <td>poultry</td>
                
                <td>Allergies</td>
                
                
                <td>Beer</td>
                <td>Wine</td>
                <td>Liquor</td>
            </tr>
            <tr>
                <td>sandun</td>
                <td>12/12/2014</td>
                
                <td>1</td>
                <td>2</td>
                
                <td>7</td>
                <td>7</td>
                <td>7</td>
                <td>2</td>
                <td>1</td>
                
                <td>have fever</td>
                
                
                <td>1</td>
                <td>3</td>
                <td>3</td>
            </tr>
            
    </thead>
</table>