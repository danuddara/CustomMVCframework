<?php 
/*the food items view*/
?>

<table class="event-calendar">
    <h3>Entertainment Items</h3>
    <thead>
        <th>Entertainment Item category</th>
        <th>Entertainmen Item name</th>
        <th>Qty needed</th>
        <th>Qty supplied</th>
        <th>By</th>
    </thead>
    <tbody>
        <tr>
            <td>Music</td>
            <td>Dj</td>
            <td>2</td>
            <td>1</td>
            <td>Dilhara</td>
        </tr>
         <tr>
            <td>Dance</td>
            <td>Fire Dancing</td>
            <td>1</td>
            <td>1</td>
            <td>Dilanke</td>
        </tr>
    </tbody>
</table>
