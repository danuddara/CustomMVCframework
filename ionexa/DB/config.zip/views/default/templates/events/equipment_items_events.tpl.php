<?php 
/*the food items view*/
?>

<table class="event-calendar">
    <h3>Equipment</h3>
    <thead>
        <th>Equipment Type</th>
        <th>Description</th>
        <th>Qty needed</th>
        <th>Qty supplied</th>
        <th>By</th>
    </thead>
    <tbody>
        <tr>
            <td>Music accessories</td>
            <td>full sound setup</td>
         
            <td>1</td>
            <td>1</td>
            <td>Maliya</td>
        </tr>
         <tr>
            <td>Video Games</td>
            <td>Xbox</td>
           
            <td>1</td>
            <td>1</td>
            <td>Suresh</td>
        </tr>
    </tbody>
</table>
