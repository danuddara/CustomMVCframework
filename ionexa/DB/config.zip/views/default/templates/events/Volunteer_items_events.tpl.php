<?php 
/*the food items view*/
?>

<table class="event-calendar">
    <h3>Volunteers</h3>
    <thead>
        <th>Work Type</th>
        <th>Description</th>
        <th>Tools needed</th>
        <th>Qty needed</th>
        <th>Qty supplied</th>
        <th>By</th>
    </thead>
    <tbody>
        <tr>
            <td>Cleaning</td>
            <td>Clean the house and the garden</td>
            <td>Broom</td>
            <td>1</td>
            <td>1</td>
            <td>Malith</td>
        </tr>
         <tr>
            <td>Driving</td>
            <td>Drive to Yala and then come back</td>
            <td>12 seater vehicle</td>
            <td>2</td>
            <td>2</td>
            <td>Dilanke</td>
        </tr>
    </tbody>
</table>
