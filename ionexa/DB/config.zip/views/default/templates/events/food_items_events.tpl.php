<?php 
/*the food items view*/
?>
<h3>Food Items</h3>
<h6>Break fast</h6>
<table class="event-calendar">
    
    <thead>
        <th>Menu Item category</th>
        <th>Menu Item name</th>
        <th>Qty needed</th>
        <th>edit</th>
        <th>Qty supplied</th>
        <th>By</th>
    </thead>
    <tbody>
        <tr >
            <td rowspan="2">Meat</td>
            <td rowspan="2">chicken</td>
            <td rowspan="2">10</td>
            <td rowspan="2"><a href="#">edit</a></td>
            <td>5</td>
            <td>Chandime</td>
        </tr>
         <tr>
            
            <td>5</td>
            <td>Dilanke</td>
        </tr>
    </tbody>
</table>
   <h6>Lunch</h6>
<table class="event-calendar">
 
    <thead>
        <th>Menu Item category</th>
        <th>Menu Item name</th>
        <th>Qty needed</th>
        <th>edit</th>
        <th>Qty supplied</th>
        <th>By</th>
    </thead>
    <tbody>
        <tr>
            <td rowspan="3">Meat</td>
            <td rowspan="3">chicken</td>
            <td rowspan="3">10</td>
            <td rowspan="3"><a href="#">edit</a></td>
            <td>5</td>
            <td>Chandime</td>
        </tr>
         <tr>
            
            <td>3</td>
            <td>Dilanke</td>
        </tr>
        <tr>
            
            <td>2</td>
            <td>Pasindu</td>
        </tr>
    </tbody>
</table>