<!--iprofile page Js-->  
<script type="text/javascript" language="javascript" src="<?php echo $baseurl ?>js/jquery-1.4.2.js"></script>
<!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
<!-- Checkbox JS -->
<!--<script type="text/javascript" src="<?php echo $baseurl ?>js/custom-form-elements.js"></script>-->
<script src="<?php echo $baseurl ?>SpryAssets/SpryEffects.js" type="text/javascript"></script>

<script type="text/javascript" src="<?php echo $baseurl ?>js/utils.js"></script>