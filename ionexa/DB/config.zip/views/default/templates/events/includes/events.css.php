<!-- iprofile page css-->  
<link rel="stylesheet" type="text/css" href="<?php echo $baseurl ?>css/bridge.css" />
<link href="<?php echo $baseurl ?>css/panels.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo $baseurl ?>css/custom.css" />

<style>
    #create_event
    {
        width: 480px;
        clear: both;
    }
    #create_event input
    {
       
    }
    #create_event label
    {
        float: left;
        width: 100px;
    }
    
.two-columns dt {
    width: 25%;
}

.event-calendar
{
    width: 100%;
    margin: 0 auto;
    clear: both;
    margin-bottom: 10px;
    
}
.event-calendar h1,h2,h3
{
      font-size: 1em;
    margin: 28px 0 5px;
    text-align: center;
    width: 100%;
}
.event-calendar, .event-calendar tr,.event-calendar td,.event-calendar th
{
    border: 1px solid #444444;
    text-align: center;
    font-size: 12px;
    
}
span.form-element
{
    margin: 10px 0;
}

.invite-friends
{
    width: 260px;
    clear: both;
    height: 170px;
    overflow: auto;
    margin: 10px 0;
}
</style>
