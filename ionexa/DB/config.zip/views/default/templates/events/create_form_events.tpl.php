

        <div class="form-panel">
            <h6>Create New Event</h6>
            <form id="create_event">
                <dl class="two-columns">
                <dt>Event Type</dt>
                <dd><select>
                        <option value="1">Gathering</option>
                        <option value="2">Baby/Bridal Shower</option>
                        <option value="3">Disaster Relief/Donation</option>
                        <option value="4">Event Proposal</option>
                        
                    </select></dd>
                <dt>Event Name</dt>
                <dd><input type="textbox" name="event_name" id="event_name"/></dd>
                <dt>Date</dt>
                <dd><input type="textbox" name="event_name" id="event_name"/></dd>
                <dt>Starting Time</dt>
                <dd><select name="starting_time_hours">
                        <?php 
                            for($i=0;$i<24;$i++)
                            {
                                ?>
                        
                         <option value="1"><?php if($i<10){print '0';}print $i;?></option>
                        <?php         
                            }
                        ?>
                    
                    </select>
                    <select name="starting_time_mins">
                         <?php 
                            for($i=0;$i<60;$i++)
                            {
                                ?>
                        
                         <option value="1"><?php if($i<10){print '0';} print $i;?></option>
                        <?php         
                            }
                        ?>
                        
                        
                    </select>
                   
                
                
                <dt>Ending Time</dt>
                <dd><select name="ending_time_hours">
                        <?php 
                            for($i=0;$i<24;$i++)
                            {
                                ?>
                        
                         <option value="1"><?php if($i<10){print '0';} print $i;?></option>
                        <?php         
                            }
                        ?>
                    
                    </select>
                    <select name="ending_time_mins">
                         <?php 
                            for($i=0;$i<60;$i++)
                            {
                                ?>
                        
                         <option value="1"><?php if($i<10){print '0';} print $i;?></option>
                        <?php         
                            }
                        ?>
                        
                        
                    </select>
                   </dd>
                 <dt>Special Notes</dt>
                <dd><span class="form-element"><textarea rows="3" cols="30" name="Description"></textarea></span></dd>
                
                <dt>Address</dt>
                <dd><span class="form-element"><textarea rows="3" cols="30" name="Description"></textarea></span></dd>
              
                <dt>Contact Person(s)</dt>
                <dd><span class="form-element"><label>Name:</label><input type="textarea"/></span><span class="form-element"><label>Contact No:</label><input type="textarea"/></span></dd>
                
                
                 <dt>Invite friends</dt>
                 <div class="invite-friends">
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Pasindu Wijesekera</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Dilanke Iresh</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Hasith Malinga</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Gina Daluwattha</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Marika Silva</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Pasindu Wijesekera</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Dilanke Iresh</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Hasith Malinga</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Gina Daluwattha</dd>
                    <dd><input class="profileids" type="checkbox" name="invitee[]" value="1"/>Marika Silva</dd>
                    
                </div>
               <dt>Confirm Attendance By</dt>
                <dd><input type="textbox" name="event_name" id="event_name"/></dd>
                <dt>Dress Code</dt>
                <dd><select>
                        <option value="1">Black Tie</option>
                        <option value="2">Tuxedo</option>
                        <option value="3">Formal</option>
                        <option value="4">Casual</option>
                        <option value="4">Costume</option>
                        <option value="4">Other</option>
                        
                    </select></dd>
                 
                <dt>Event For</dt>
                <dd>
                    <select>
                        <option value="1">All</option>
                        <option value="2">Adults only</option>
                        <option value="3">Children Only</option>
                   </select>
                </dd>
                   
                <dt>Parking Instructions</dt>
                <dd><span class="form-element"><textarea rows="3" cols="30" name="Description"></textarea></span></dd>
                
                <dt><b>Need Detail Planning?</b></dt>
                <dd><span class="form-element"><input type="checkbox"/></span></dd>
                
                <dt>Add Dietary restrictions ?</dt>
                <dd><span class="form-element"><input type="checkbox"/></span></dd>
                
                <dt>Add Allergies ?</dt>
                <dd><span class="form-element"><input type="checkbox"/></span></dd>
                
                <dt>Add Spirits ?</dt>
                <dd><span class="form-element"><input type="checkbox"/></span></dd>
                
                
                
                
                <div id="detailed-plan">
                </div>  
                <div id="Continue-plan">
                    <div class="food">
                        
                        
                        
                        
                        
                        
                           <div class="info-panel">
                              <div class="panelcollapsed">
                                <h2 class="section-title"><span class="title">Food</span></h2>
                                <div class="panelcontent">
                                            <div>
                                                <table class="event-calendar">
                                                    <h3>Food Items</h3>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="4">Breakfast</th>
                                                        </tr>
                                                    </thead>
                                                        
                                                      
                                                    
                                                    <tbody>
                                                        <tr>
                                                            <td>Meal Type</td>
                                                            <td>Category</td>
                                                            <td>Qty needed</td>
                                                            <td>Request Contributors?</td>
                                                            <td>edit</td>
                                                         </tr>   
                                                        
                                                        <tr>
                                                            <td>Meat</td>
                                                            <td>chicken</td>
                                                            <td>10</td>
                                                            <td>yes</td>
                                                            <td><a href="#">edit</a></td>
                                                          
                                                        </tr>
                                                         <tr>
                                                            <td>Meat</td>
                                                            <td>chicken</td>
                                                            <td>10</td>
                                                            <td>yes</td>
                                                            <td><a href="#">edit</a></td>
                                                            
                                                        </tr>
                                                        
                                                        <tr>
                                                            <th colspan="3">Lunch</th>
                                                        </tr>
                                                         <tr>
                                                            <td>Meal Type</td>
                                                            <td>Category</td>
                                                            <td>Qty needed</td>
                                                            <td>Request Contributors?</td>
                                                            <td>edit</td>
                                                         </tr> 
                                                        <tr>
                                                            <td>Meat</td>
                                                            <td>chicken</td>
                                                            <td>10</td>
                                                            <td>yes</td>
                                                            <td><a href="#">edit</a></td>
                                                          
                                                        </tr>
                                                         <tr>
                                                            <td>Meat</td>
                                                            <td>chicken</td>
                                                            <td>10</td>
                                                            <td>yes</td>
                                                            <td><a href="#">edit</a></td>
                                                            
                                                        </tr>
                                                        
                                                    </tbody>
                                                </table>

                                            </div>    
                                    
                                    
                                    
                                    
                                            <dt>Meal Type</dt>
                                            <dd>
                                                <select>
                                                    <option value="1">Break Fast</option>
                                                    <option value="2">Snack/Refreshment/Tea Party</option>
                                                    <option value="3">Brunch</option>
                                                    <option value="4">Lunch</option>
                                                    <option value="4">Dinner</option>
                                               </select>
                                            </dd>
                                            <dt>Category</dt>
                                            <dd>
                                                <select>
                                                    <option value="1">Meat</option>
                                                    <option value="2">Poultry</option>
                                                    <option value="3">Seafood</option>
                                                    <option value="4">Vegetable</option>
                                                    <option value="5">Bakery</option>
                                                    <option value="6">Pasta</option>
                                                    <option value="7">Rice</option>
                                                    <option value="8">Ethnic Food</option>
                                                    <option value="9">Beverage</option>
                                                    <option value="10">Beer</option>
                                                    <option value="11">Spirit/Alcohol</option>

                                               </select>
                                            </dd>
                                            <dt>List Items for category</dt>
                                            <dd>
                                                <select>
                                                    <option value="1">Chicken</option>
                                                    <option value="2">Turkey</option>
                                                    <option value="3">Beef</option>
                                                    <option value="4">Mutton</option>


                                               </select>
                                            </dd>
                                             <dt>Menu Name</dt>
                                            <dd><input type="textbox" name="event_name" id="event_name"/></dd>
                                            <dt>Quantity</dt>
                                            <dd><input type="textbox" name="event_name" id="event_name"/></dd>

                                             <dt>Request Contributors?</dt>
                                             <dd><span class="form-element"><input type="checkbox"/></span></dd>

                                               <dl>
                                            <input type="submit" value="Add-Food" name="createEvent-submit"/>
                                            </dl>
                                </div>
                              </div>
                            </div>
                        
                        
                         
                    </div>
                    <div class="entertaiment">
                        
                           <div class="info-panel">
                              <div class="panelcollapsed">
                                <h2 class="section-title"><span class="title">Entertainment</span></h2>
                                <div class="panelcontent">
                                           
                                         <div>
                                                <table class="event-calendar">
                                                    <h3>Entertainment Items</h3>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="6">Music</th>
                                                        </tr>
                                                    </thead>
                                                        
                                                      
                                                    
                                                    <tbody>
                                                        <tr>
                                                            <td>Category</td>
                                                            <td>List Item</td>
                                                            <td>Name</td>
                                                            <td>Quantity</td>
                                                            <td>Request Contributors?</td>
                                                            <td>edit</td>
                                                         </tr>   
                                                        
                                                        <tr>
                                                            <td>Live Band</td>
                                                            <td>classical</td>
                                                            <td>Sa</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                          
                                                        </tr>
                                                         <tr>
                                                            <td>Live Band</td>
                                                            <td>Rock</td>
                                                            <td>SaRock</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                            
                                                        </tr>
                                                        
                                                        <tr>
                                                            <th colspan="6">Dance</th>
                                                        </tr>
                                                         <tr>
                                                            <td>Category</td>
                                                            <td>List Item</td>
                                                            <td>Name</td>
                                                            <td>Quantity</td>
                                                            <td>Request Contributors?</td>
                                                            <td>edit</td>
                                                         </tr> 
                                                         <tr>
                                                            <td>Live Band</td>
                                                            <td>classical</td>
                                                            <td>Sa</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                          
                                                        </tr>
                                                         <tr>
                                                            <td>Live Band</td>
                                                            <td>Rock</td>
                                                            <td>SaRock</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                            
                                                        </tr>
                                                        
                                                    </tbody>
                                                </table>

                                            </div> 
                                    
                                    
                                            <dt>Entertainment Type</dt>
                                            <dd>
                                                <select>
                                                    <option value="1">Music</option>
                                                    <option value="2">Dance</option>
                                                    <option value="3">Adult Games</option>
                                                    <option value="4">Children Games</option>
                                                    <option value="5">Children Entertainment</option>
                                                    <option value="6">Adult Entertainment</option>
                                               </select>
                                            </dd>
                                            <dt>Category</dt>
                                            <dd>
                                                <select>
                                                    <option value="1">Live band</option>
                                                    <option value="2">Artist</option>
                                                    <option value="3">DJ</option>
                                                    <option value="4">Other</option>


                                               </select>
                                            </dd>
                                            <dt>List Items for category</dt>
                                            <dd>
                                                <select>
                                                    <option value="1">Rock</option>
                                                    <option value="2">Classical</option>
                                                    <option value="3">Western</option>

                                               </select>
                                            </dd>
                                             <dt>Name</dt>
                                            <dd><input type="textbox" name="event_name" id="event_name"/></dd>
                                            <dt>Quantity</dt>
                                            <dd><input type="textbox" name="event_name" id="event_name"/></dd>

                                             <dt>Request Contributors?</dt>
                                             <dd><span class="form-element"><input type="checkbox"/></span></dd>

                                             <dl>
                                            <input type="submit" value="Add-Entertainment" name="createEvent-submit"/>
                                            </dl>
                                </div>
                              </div>
                          </div>
                        
                        
                         
                    </div>
                    <div class="volunteer">
                        
                           <div class="info-panel">
                              <div class="panelcollapsed">
                                <h2 class="section-title"><span class="title">Volunteers</span></h2>
                                <div class="panelcontent">
                                    
                                            <div>
                                                <table class="event-calendar">
                                                    <h3>Work List</h3>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="5">Cleaning</th>
                                                        </tr>
                                                    </thead>
                                                        
                                                      
                                                    
                                                    <tbody>
                                                        <tr>
                                                            <td>Description</td>
                                                            <td>Tools needed</td>
                                                            <td>Quantity</td>
                                                            <td>Request Contributors?</td>
                                                            <td>edit</td>
                                                         </tr>   
                                                        
                                                        <tr>
                                                            <td>Hellow eorwa asd asdsa the asworkd</td>
                                                            <td>wheels</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                          
                                                        </tr>
                                                         <tr>
                                                            <td>Hellow eorwa asd asdsa the asworkd</td>
                                                            <td>wheels</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                            
                                                        </tr>
                                                        
                                                        <tr>
                                                            <th colspan="5">cooking</th>
                                                        </tr>
                                                          <tr>
                                                            <td>Description</td>
                                                            <td>Tools needed</td>
                                                            <td>Quantity</td>
                                                            <td>Request Contributors?</td>
                                                            <td>edit</td>
                                                         </tr>   
                                                        
                                                        <tr>
                                                            <td>Hellow eorwa asd asdsa the asworkd</td>
                                                            <td>wheels</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                          
                                                        </tr>
                                                         <tr>
                                                            <td>Hellow eorwa asd asdsa the asworkd</td>
                                                            <td>wheels</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                            
                                                        </tr>
                                                        
                                                    </tbody>
                                                </table>

                                            </div> 
                                    
                                            <dt>Work Type</dt>
                                            <dd>
                                                <select>
                                                    <option value="1">Cleaning</option>
                                                    <option value="2">Construction</option>
                                                    <option value="3">Cooking</option>
                                                    <option value="4">Decoration</option>
                                                    <option value="5">Driving</option>
                                                    <option value="6">Loading/Unloading</option>
                                                    <option value="7">Parking</option>
                                                    <option value="8">Painting</option>
                                                    <option value="9">Renovating</option>
                                                    <option value="10">Ushering</option>
                                                    <option value="11">Video/Photography</option>
                                                    <option value="12">Other</option>
                                               </select>
                                            </dd>
                                            <dt>Description</dt>
                                            <dd>
                                                <span class="form-element"><textarea rows="3" cols="30" name="Description"></textarea></span>
                                            </dd>
                                            <dt>Tools Needed</dt>
                                            <dd>
                                                <span class="form-element"><textarea rows="3" cols="30" name="Description"></textarea></span>
                                            </dd>


                                            <dt>Quantity</dt>
                                            <dd><input type="textbox" name="event_name" id="event_name"/></dd>

                                             <dt>Request Contributors?</dt>
                                             <dd><span class="form-element"><input type="checkbox"/></span></dd>

                                             <dl>
                                            <input type="submit" value="Add-Work" name="createEvent-submit"/>
                                            </dl>
                                </div>
                              </div>
                            </div>
                        
                      
                         
                    </div>
                    
                     <div class="Equipment">
                         
                            <div class="info-panel">
                              <div class="panelcollapsed">
                                <h2 class="section-title"><span class="title">Equipment</span></h2>
                                <div class="panelcontent">
                                        
                                    
                                        <div>
                                                <table class="event-calendar">
                                                    <h3>Equipment List</h3>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="4">Music accessories</th>
                                                        </tr>
                                                    </thead>
                                                        
                                                      
                                                    
                                                    <tbody>
                                                        <tr>
                                                            <td>Description</td>
                                                            <td>Quantity</td>
                                                            <td>Request Contributors?</td>
                                                            <td>edit</td>
                                                         </tr>   
                                                        
                                                        <tr>
                                                            <td>Hellow eorwa asd asdsa the asworkd</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                          
                                                        </tr>
                                                         <tr>
                                                            <td>Hellow eorwa asd asdsa the asworkd</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                            
                                                        </tr>
                                                        
                                                        <tr>
                                                            <th colspan="5">Video games</th>
                                                        </tr>
                                                         <tr>
                                                            <td>Description</td>
                                                            <td>Quantity</td>
                                                            <td>Request Contributors?</td>
                                                            <td>edit</td>
                                                         </tr>   
                                                        
                                                        <tr>
                                                            <td>Hellow eorwa asd asdsa the asworkd</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                          
                                                        </tr>
                                                         <tr>
                                                            <td>Hellow eorwa asd asdsa the asworkd</td>
                                                            <td>1</td>
                                                            <td>Yes</td>
                                                            <td><a href="#">edit</a></td>
                                                            
                                                        </tr>
                                                    </tbody>
                                                </table>

                                            </div> 
                                    
                                        <dt>Equipment Type</dt>
                                        <dd>
                                            <select>
                                                <option value="1">Music accessories</option>
                                                <option value="2">Indoor Games</option>
                                                <option value="3">Outdoor Games</option>
                                                <option value="4">Video Games</option>
                                                <option value="5">Furniture</option>
                                                <option value="6">sound equipment’s</option>
                                                <option value="7">Other</option>

                                           </select>
                                        </dd>
                                        <dt>Description</dt>
                                        <dd>
                                            <span class="form-element"><textarea rows="3" cols="30" name="Description"></textarea></span>
                                        </dd>


                                        <dt>Quantity</dt>
                                        <dd><input type="textbox" name="event_name" id="event_name"/></dd>

                                         <dt>Request Contributors?</dt>
                                         <dd><span class="form-element"><input type="checkbox"/></span></dd>

                                         <dl>
                                        <input type="submit" value="Add-Equipment" name="createEvent-submit"/>
                                        </dl>
                                </div>
                              </div>
                            </div>
                         
                        
                         
                    </div>
                     <dl>
                    <input type="submit" value="Create New Event" name="createEvent-submit"/>
                    </dl>
                    
                </div> 
                
                
                
           
                
                </dl>
               
            </form>
            
                               
                 
            
            
        </div>
    
   

<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
