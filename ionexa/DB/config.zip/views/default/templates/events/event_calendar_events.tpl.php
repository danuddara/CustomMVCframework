
<div class="info-panel">
<table class="event-calendar">
    <thead>
            <th>Date</th>
            <th>title</th>
            <th>Confirmed</th>
            <th>Managed</th>
    </thead>
    <tbody>
        <tr>
            <td>12/12/2014</td>
            <td>Trip To Yala</td>
            <td>20</td>
            <td><a href="#">cancel</a>|<a href="<?php print __BASE_URL;?>events/viewEvent">View</a></td>
        </tr>
    </tbody>
</table>
</div>