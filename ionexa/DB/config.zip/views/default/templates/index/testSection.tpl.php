<div style="clear:both">
<h1><?php echo $heading; ?></h1>
<p>This is the Custom Section of the page</p>
<p>You can put whatever content you like here such as search for your site</p>
</div>