<!-- page css-->  
<link rel="stylesheet" type="text/css" href="<?php echo $baseurl ?>css/bridge.css" />
