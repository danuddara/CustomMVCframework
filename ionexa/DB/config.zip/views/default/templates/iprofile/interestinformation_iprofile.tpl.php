    <?php 
                  
                 $adminpanel= '';
                 
                     if($user=='admin')
                     {
                         $adminpanel='
                 <a href="'.__BASE_URL.'iprofile/edit?field=interestinformation" class="edit">Edit</a>
                  <a href="#" class="security">Privacy</a>';
                          $adddelete ='<a href="#" class="delete">Delete</a> <a href="#" class="add">Add</a>';
                    
                     }
?>
<div class="info-panel">
          <div class="panelcollapsed">
            <h2 class="section-title"><span class="title">Interest Information</span>
            
                <?php  echo $adminpanel; ?>
            </h2>
            <div class="panelcontent">
              <ol class="multiple-records">
                  <?php if($fields!=null){
                      
                    foreach($fields as $field=>$show)
                    {
                        
                        $tsfield= 'interestinformation_iprofile_'.$field;
                        
                        $firstnamedis = 'interestinformation_iprofile_firstname_'.$field;
                        $bdaydatedis = 'interestinformation_iprofile_bdaydate_'.$field;
                       
                      if($$tsfield==true){ ?>
                <li>
                  <ul class="random-columns">
                  <li><span class="label">Name<a class="help"></a></span><span class="form-element">
                      <input name="name" type="text" />
                      </span></li>
                    <li><span class="label">Type</span>
                        <span class="form-element">
                            <input name="type" type="text" />
                        </span>
                    </li>
                                     
                    <li><span class="label">Description</span><span class="form-element">
                      <textarea name="Description" cols="30" rows="3" ></textarea>
                      </span></li>
                      
                 
                                     
                     
                   </ul>
                </li>
                   <?php 
                        }
                    }
                }?>
              </ol>
              <h2 class="section-footer"><?php echo $adddelete?></h2>
            </div>
          </div>
        </div>