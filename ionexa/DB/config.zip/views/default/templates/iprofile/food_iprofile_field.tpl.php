<li>
                  <ul class="random-columns">
                  <li><span class="label"><?php echo _('Dish');?><a class="help"></a></span><span class="form-element">
                          <input type="text" value="" name="name[]">
                      </span></li>
                               
                    <li><span class="label"><?php echo _('Category');?></span><span class="form-element">
                      <textarea rows="3" cols="30" name="Description[]"></textarea>
                      </span></li>
                      
                      <li><input type="hidden" value="Foodd_1" name="field[]"></li>
                 
                                     
                     
                   </ul>
                </li>