<li>
                  <ul class="random-columns">
                    <li><span class="label"><?php echo _('Sport'); ?><a class="help"></a></span><span class="form-element">
                      <input type="text" value="" name="type[]">
                      </span></li>
                      
                  <li><span class="label"><?php echo _('Team');?><a class="help"></a></span><span class="form-element">
                      <input type="text" value="" name="name[]">
                      </span></li>
                               
                 <?php /*   <li><span class="label">Description</span><span class="form-element">
                      <textarea rows="3" cols="30" name="Description[]"></textarea>
                      </span></li>*/ ?>
                      
                      <li><input type="hidden" value="sportss_1" name="field[]"></li>
                                     
                     
                   </ul>
                </li>