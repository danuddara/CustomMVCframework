<li>
                  <ul class="random-columns">
                        <li><span class="label"><?php echo _('Type');?></span>
                        <span class="form-element">
                            
                            <select name="type[]">
                                                                <option><?php echo _('Academic and Professional');?></option>
                                                                <option><?php echo _('Arts, Photography and Design');?></option>
                                                                <option><?php echo _('Award Winning');?></option>
                                                                <option><?php echo _('Biographies &amp; Autobiographies');?></option>
                                                                <option><?php echo _('Business, Investing and Management');?></option>
                                                                <option><?php echo _('Comics &amp; Graphic Novels');?></option>
                                                                <option><?php echo _('Cooking, Food &amp; Wine');?></option>
                                                            </select>
                            
                        </span>
                    </li>
                <li><span class="label"><?php echo _('Author');?><a class="help"></a></span>
                        <span class="form-element">
                      <input type="text" value="" name="author[]">
                      </span></li>
                    
                    <li><span class="label"><?php echo _('Title');?></span><span class="form-element">
                      <input type="text" name="title[]"/>
                      </span></li>
                      
                 <li><input type="hidden" value="bookk_1" name="field[]"></li>
                                     
                     
                   </ul>
                </li>