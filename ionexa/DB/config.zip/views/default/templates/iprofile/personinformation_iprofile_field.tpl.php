<li>
                  <ul class="random-columns">
                    <li><span class="label">Type</span>
                        <span class="form-element">
                            <select id="type" name="type[]">
                                
                                                                
                                <option><?php echo _('Actor');?></option>
                                
                                                                
                                <option><?php echo _('Singer');?></option>
                                
                                                                
                                <option><?php echo _('Cook');?></option>
                                
                                                                
                                <option><?php echo _('Comedian');?></option>
                                
                                                                
                                <option><?php echo _('TV Personality');?></option>
                                
                                                                
                                <option><?php echo _('Radio Personality');?></option>
                                
                                                                
                                <option><?php echo _('Most Inspiring');?></option>
                                
                                                                
                                <option><?php echo _('Sportsman');?></option>
                                
                                                                
                                <option><?php echo _('Athlete');?></option>
                                
                                                                
                                <option><?php echo _('Businessman');?></option>
                                
                                                            </select>
                        </span>
                    </li>
                    <li><span class="label"><?php echo _('Name');?><a class="help"></a></span><span class="form-element">
                      <input type="text" value="" name="name[]">
                      </span></li>
                    
               <?php /*      <li><span class="label">Description</span><span class="form-element">
                      <textarea rows="3" cols="30" name="Description[]"></textarea>
                      </span></li>*/?>
                      
                      <li><input type="hidden" li=""  value="personn_1" name="field[]">
                                     
                     
                   </li></ul>
                </li>