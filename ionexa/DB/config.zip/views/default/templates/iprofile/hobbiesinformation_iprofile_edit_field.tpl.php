<li>
<ul class="random-columns">
                        <li><span class="label"><?php echo _('Name');?><a class="help"></a></span><span class="form-element">
                      <input name="name[]" type="text" value="">
                      </span></li>
                    <li><span class="label"><?php echo _('Category');?></span>
                        <span class="form-element">
                            <input name="type[]" type="text" value="">
                        </span>
                    </li>
                                     
                   <?php /* <li><span class="label">Description</span><span class="form-element">
                      <textarea name="Description[]" cols="30" rows="3"></textarea>
                      </span></li>*/?>
                      
                      <li><input type="hidden" name="field[]" value="hobbiess_1"></li>
                                     
                     
                   </ul>
</li>